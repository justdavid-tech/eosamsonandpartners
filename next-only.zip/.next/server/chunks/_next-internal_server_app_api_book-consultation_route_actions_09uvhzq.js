module.exports=[824578,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_book-consultation_route_actions_09uvhzq.js.map