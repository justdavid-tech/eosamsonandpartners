module.exports=[190239,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice-areas_%5Bslug%5D_page_actions_1tumggu.js.map