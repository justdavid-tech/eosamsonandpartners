module.exports=[416926,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_studio_%5B%5B___tool%5D%5D_page_actions_1n313tn.js.map