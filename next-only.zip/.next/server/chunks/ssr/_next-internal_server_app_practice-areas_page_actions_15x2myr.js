module.exports=[725251,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice-areas_page_actions_15x2myr.js.map