module.exports=[962824,a=>{"use strict";var b=a.i(984995);a.s([],978360),a.i(978360),a.s(["default",()=>b.DocumentPane],962824)}];

//# sourceMappingURL=02zn_sanity_lib__chunks-es_pane_1adcuis.js.map