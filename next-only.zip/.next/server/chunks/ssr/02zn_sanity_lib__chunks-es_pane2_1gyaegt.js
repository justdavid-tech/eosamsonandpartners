module.exports=[902440,a=>{"use strict";var b=a.i(984995);a.s([],496200),a.i(496200),a.s(["default",()=>b.PaneContainer],902440)}];

//# sourceMappingURL=02zn_sanity_lib__chunks-es_pane2_1gyaegt.js.map