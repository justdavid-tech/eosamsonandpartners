1:"$Sreact.fragment"
2:I[733168,["/_next/static/chunks/2-34qze7vg5w-.js","/_next/static/chunks/1d9-6xa0385cg.js"],"default"]
3:I[723878,["/_next/static/chunks/2-34qze7vg5w-.js","/_next/static/chunks/1d9-6xa0385cg.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"ZtHMfg2cRn6OskFWJytoK"}
