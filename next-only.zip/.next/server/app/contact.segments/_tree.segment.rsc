:HL["/_next/static/chunks/3wvn9oc2dcxeq.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Recursive:wght@300..1000&display=swap","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"contact","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"ZtHMfg2cRn6OskFWJytoK"}
