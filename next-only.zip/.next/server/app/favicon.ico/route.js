var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__0_wcvj9._.js")
R.c("server/chunks/0a48_next_dist_esm_build_templates_app-route_15j85y0.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_0g2jjls.js")
R.m(827497)
module.exports=R.m(827497).exports
