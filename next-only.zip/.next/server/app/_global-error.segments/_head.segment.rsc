1:"$Sreact.fragment"
2:I[792563,["/_next/static/chunks/0_kadzga8kune.js","/_next/static/chunks/1d9-6xa0385cg.js"],"ViewportBoundary"]
3:I[792563,["/_next/static/chunks/0_kadzga8kune.js","/_next/static/chunks/1d9-6xa0385cg.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[357453,["/_next/static/chunks/0_kadzga8kune.js","/_next/static/chunks/1d9-6xa0385cg.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.2vob68tjqpejf.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"ZtHMfg2cRn6OskFWJytoK"}
