var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/book-consultation/route.js")
R.c("server/chunks/[root-of-the-server]__1pj_f1p._.js")
R.c("server/chunks/[root-of-the-server]__0_wcvj9._.js")
R.c("server/chunks/_next-internal_server_app_api_book-consultation_route_actions_09uvhzq.js")
R.m(863925)
module.exports=R.m(863925).exports
