var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/contact/route.js")
R.c("server/chunks/[root-of-the-server]__029xu5_._.js")
R.c("server/chunks/[root-of-the-server]__0_wcvj9._.js")
R.c("server/chunks/_next-internal_server_app_api_contact_route_actions_03lj3y1.js")
R.m(108193)
module.exports=R.m(108193).exports
