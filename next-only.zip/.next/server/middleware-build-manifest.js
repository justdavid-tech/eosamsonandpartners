globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/ZtHMfg2cRn6OskFWJytoK/_buildManifest.js",
    "static/ZtHMfg2cRn6OskFWJytoK/_ssgManifest.js",
    "static/ZtHMfg2cRn6OskFWJytoK/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2gmatl7553ypp.js",
    "static/chunks/0zyu6vihbxu4j.js",
    "static/chunks/15--o44187vwq.js",
    "static/chunks/2vi3n-u7h5kc1.js",
    "static/chunks/3xjwlc-1ilkyu.js",
    "static/chunks/turbopack-1f2wii8j8v5kj.js"
  ]
};
